import React, { Component } from 'react';
class PricingBlock extends Component {
  render() {
    return (
      <section>
        <h1>{this.props.test}</h1>
    </section>
    );
  }
}

export default PricingBlock;
