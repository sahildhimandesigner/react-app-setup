import React, { Component } from 'react';
import ListItem from '../components/ListItem';
function NumberList(props) {
  const numbers = props.numbers;
  const ListItem = numbers.map((number) =>
    // Wrong! The key should have been specified here:
    <ListItem value={number} />
  );
  return (
    <ul>
      {ListItem}
    </ul>
  );
}
export default NumberList;
